# 🔍 Agent Lens

AI Agent 追踪和成本优化 CLI 工具。

追踪每一次 API 调用，分析 token 用量，优化你的 AI 成本。

## 安装

```bash
pip install agent-lens
```

## 快速开始

```bash
# 生成演示数据
agent-lens demo

# 查看总览
agent-lens stats

# 按模型统计
agent-lens report --by model

# 成本排行
agent-lens cost

# 最近调用
agent-lens recent -n 10

# 导出数据
agent-lens export --json -o traces.json
```

## 代码集成

### 装饰器方式

```python
from agent_lens import AgentLens

lens = AgentLens(agent_name="my-agent")

@lens.track(model="gpt-4o")
def call_api(prompt):
    return client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}],
    )
```

### Context Manager 方式

```python
from agent_lens import AgentLens

lens = AgentLens(agent_name="my-agent")

with lens.trace(model="gpt-4o") as t:
    result = client.chat.completions.create(...)
    t.input_tokens = result.usage.prompt_tokens
    t.output_tokens = result.usage.completion_tokens
```

### 直接记录

```python
from agent_lens import AgentLens

lens = AgentLens(agent_name="my-agent")
lens.record(
    model="gpt-4o",
    input_tokens=1500,
    output_tokens=800,
    latency_ms=2300,
)
```

### 全局快捷方式

```python
from agent_lens import record, trace, track

# 直接记录
record(model="gpt-4o", input_tokens=100, output_tokens=50)

# Context Manager
with trace(model="gpt-4o") as t:
    ...

# 装饰器
@track(model="gpt-4o")
def my_func():
    ...
```

## CLI 命令

| 命令 | 说明 |
|------|------|
| `agent-lens stats` | 总览统计 |
| `agent-lens report` | 按模型/提供商分组 |
| `agent-lens cost` | 成本排行 |
| `agent-lens recent` | 最近调用 |
| `agent-lens top` | 成本最高的调用 |
| `agent-lens export` | 导出 CSV/JSON |
| `agent-lens clean` | 清理旧数据 |
| `agent-lens demo` | 生成演示数据 |

## 支持的模型

OpenAI、Anthropic、Google、DeepSeek、Mistral、Qwen、GLM、MiMo 等主流模型的定价数据。

## 数据存储

数据存储在 `~/.agent-lens/traces.db` (SQLite)，本地私密，无需云服务。

## License

MIT
